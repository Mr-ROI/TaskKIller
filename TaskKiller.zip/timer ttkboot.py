import tkinter as tk
import ttkbootstrap as ttk
import Process_getter as pg
import customtkinter as ctk
import threading
import time , json


timer_window = ttk.Window(themename="darkly")
timer_window.title("Timer")
timer_window.geometry("450x350")


def refresher():
    try:
        inlist_label.configure(text="")
    except Exception as e:
        print(e)
    process_combo['values'] = pg.get_process()


def start_thread():
    try:
        inlist_label.configure(text="")
    except Exception as e:
        print(e)
    check_json = pg.file_reader()
    if process_var.get() not in check_json:
        thread = threading.Thread(target=pg.thread_func(process_var.get(),int(time_untill.get())*60))
        thread.start()
    else:
        inlist_label.configure(text=f"{process_var.get()} is already for termination.")
        


def update_treeview():
    proce = pg.file_reader()
    exist_pro = [procees_in_ter.item(i)['values'][0] for i in procees_in_ter.get_children()]
    for i in proce:
        if i not in exist_pro:
            procees_in_ter.insert('',tk.END,values=(i,(((proce.get(i)) - (time.time()))//60)))
    


timer_tab = ttk.Notebook(timer_window, bootstyle='info')
tab1 = ttk.Frame(timer_tab)
tab2 = ttk.Frame(timer_tab)
timer_tab.add(tab1, text = "TimeBomber")
timer_tab.add(tab2, text = "Process")
timer_tab.pack(padx = 10, pady = 10,fill = 'both',expand=True)


label = ttk.Label(tab1,text='Timer Bomber', font=('Jokerman',20))
label.pack(padx = 5, pady = 5)


cur_process = pg.get_process()
process_var = tk.StringVar(value=cur_process[0])
process_combo = ttk.Combobox(tab1,textvariable=process_var)
process_combo['values'] = cur_process
process_combo.pack(padx = 5, pady = 5)
process_combo.bind('<<ComboboxSelected>>', lambda event: print(event))


time_untill = tk.IntVar(value=30)
values = list(range(30,121,30))
process_segbutton = ctk.CTkSegmentedButton(tab1,values=values ,variable=time_untill, command=lambda val: time_label.configure(text=f'{str(time_untill.get())} mins'))
process_segbutton.pack(padx = 5, pady = 5)


time_label = ttk.Label(master=tab1,text='0 mins')
time_label.pack(padx = 5, pady = 5)


inlist_label = ttk.Label(master=tab1,text='')
inlist_label.pack(padx = 5, pady = 5)


conforim_but = ttk.Button(tab1,text='Conform',command= start_thread)
conforim_but.pack(padx = 5, pady = 5)


refresh_button = ttk.Button(tab1,text='Refresh' , command= refresher)
refresh_button.pack(padx = 5, pady = 5)


procees_in_ter = ttk.Treeview(tab2, columns=("Process","TimeReam"), show = 'headings')
procees_in_ter.heading('Process',text = "Process")
procees_in_ter.heading('TimeReam',text = "Time Remaning")
procees_in_ter.pack(fill='both',expand=True)


def close_win():
    with open('process_.json', 'w') as opener:
        json.dump({},opener)
    timer_window.destroy()


timer_window.protocol('WM_DELETE_WINDOW',close_win)
timer_window.bind('<Motion>', lambda event: update_treeview())
timer_window.mainloop()