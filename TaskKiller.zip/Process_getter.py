import os
import re
import time
import json

def get_process():
    procoess_running = os.popen('Powershell "gps | where {$_.mainwindowtitle}  | select path"').readlines()
    operations = [re.split(r'(\\)' ,i)[-1].strip() for i in procoess_running[3:]]
    return operations    
    

def file_reader():
    with open('process_.json','r') as read_json:
        return json.load(read_json)


def thread_func(TaskName:str, Timekiller):
    def TaskKiller():
        file_con = file_reader()
        if TaskName not in file_con:
            with open('process_.json' , 'w') as write_json:
                file_con[TaskName] = time.time()+Timekiller
                json.dump(file_con, write_json)
            time.sleep(Timekiller)
            os.system(f"taskkill /im {TaskName}")
            file_rewrite = file_reader()
            with open('process_.json' , 'w') as write_json:
                file_rewrite.pop(TaskName)
                json.dump(file_rewrite,write_json)
    
    return TaskKiller